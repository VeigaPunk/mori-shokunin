import json, re, subprocess, sys

REPO = "/home/vgpnk/Projects/shokunin/mori-shokunin"
BASE = "56ac3badb4d84ed5b0b117d6295fc832341e01f3"
POLICY = ".ufo/waves/round-18/frozen/c1-policy.json"


def git(*args):
    return subprocess.run(["git", "-C", REPO, *args], capture_output=True, check=True).stdout


policy = json.loads(git("show", BASE + ":" + POLICY))
classes = [(c["id"], re.compile(c["regex"])) for c in policy["classes"]]


def hits(rev, path):
    try:
        data = git("show", rev + ":" + path)
    except subprocess.CalledProcessError:
        return set()
    if b"\0" in data:
        return set()
    out = set()
    for line in data.decode("utf-8", errors="replace").split("\n"):
        for cid, rx in classes:
            if rx.search(line):
                out.add((cid, line))
    return out


for rev in sys.argv[1:]:
    changed = git("diff", "--name-only", BASE, rev).decode().split("\n")
    new_total = 0
    per = {}
    for path in filter(None, changed):
        delta = hits(rev, path) - hits(BASE, path)
        if delta:
            per[path] = sorted(set(c for c, _ in delta))
            new_total += len(delta)
    print(json.dumps({"rev": rev, "changed_files": len([p for p in changed if p]),
                      "new_hit_keys": new_total, "files": per}))
