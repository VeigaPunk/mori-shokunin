import json, os, sys, glob
ESC={"040":" ","011":"\t","012":"\n","134":"\\"}
def dec(s):
    o=[];i=0
    while i<len(s):
        if s[i]=="\\":
            e=s[i+1:i+4]
            if e not in ESC: raise ValueError("esc:"+e)
            o.append(ESC[e]); i+=4; continue
        o.append(s[i]); i+=1
    return "".join(o)
XQ={"usrquota","uquota","quota","grpquota","gquota","prjquota","pquota"}
XN={"uqnoenforce","gqnoenforce","pqnoenforce","qnoenforce"}
EXT={"quota","noquota","usrquota","grpquota","prjquota","usrjquota","grpjquota","jqfmt"}
TM={"quota","usrquota","grpquota","usrquota_block_hardlimit","usrquota_inode_hardlimit","grpquota_block_hardlimit","grpquota_inode_hardlimit"}
def parse(text):
    ms=[]
    for ln in text.split("\n"):
        if not ln.strip(): continue
        f=ln.split(" ")
        sep=f.index("-")
        if sep<6 or len(f)-sep-1!=3: raise ValueError("line")
        maj,mi=f[2].split(":")
        ms.append(dict(id=int(f[0]),par=int(f[1]),dev=(int(maj),int(mi)),root=dec(f[3]),mp=dec(f[4]),fs=f[-3],src=dec(f[-2]),opts=f[-1]))
    return ms
def classify(fx,row,ms):
    rp=row["realpath"]
    cov=[m for m in ms if m["mp"]==rp or m["mp"]=="/" or rp.startswith(m["mp"]+"/")]
    if not cov: return (None,None,"unknown","n/a","no_covering_mount"),"nc",cov,None
    if len({m["mp"] for m in cov})!=len(cov): return (None,None,"unknown","n/a","ambiguous_overmount"),"dup",cov,None
    best=max(cov,key=lambda m:len(m["mp"]))
    sh=[m for m in cov if len(m["mp"])<len(best["mp"])]
    note=None
    if sh:
        anc=max(sh,key=lambda m:len(m["mp"]))
        ids={m["id"] for m in ms}
        if best["par"] in ids and best["par"]!=anc["id"]:
            return (None,None,"unknown","n/a","ambiguous_overmount"),"parent",cov,(best["id"],best["par"],anc["id"])
        note=(best["id"],best["par"],anc["id"])
    maj,mi=map(int,row["st_dev"].split(":"))
    if best["dev"]==(maj,mi): dc="match"
    elif best["fs"]=="btrfs" and maj==0: dc="skip"
    else: return (best["fs"],best["mp"],"unknown","n/a","device_mismatch"),"mismatch",cov,note
    keys={o.split("=",1)[0] for o in best["opts"].split(",") if o}
    fs=best["fs"]
    if fs=="xfs":
        if "noquota" in keys and keys&(XQ|XN): r=("unknown","n/a","xfs_conflicting_quota_options")
        elif "noquota" in keys: r=("disabled","n/a","xfs_noquota_option")
        elif keys&XQ: r=("enabled","enforced","xfs_quota_option")
        elif keys&XN: r=("enabled","accounting_only","xfs_quota_option")
        else: r=("unknown","n/a","xfs_quota_options_absent")
    elif fs=="btrfs":
        src=best["src"]; mapped=fx["device_links"].get(src); bn=os.path.basename(mapped if mapped else src)
        hits=[u for u,v in fx["btrfs_sysfs"].items() if bn in v["devices"]]
        if len(hits)!=1: r=("unknown","n/a","btrfs_device_unmapped")
        else:
            v=fx["btrfs_sysfs"][hits[0]]
            if v["qgroups"] is False: r=("disabled","n/a","btrfs_qgroups_dir_absent")
            elif v["qgroups_enabled"] is True: r=("enabled","unknown","btrfs_qgroups_enabled")
            elif v["qgroups_enabled"] is False: r=("disabled","n/a","btrfs_qgroups_disabled")
            else: r=("unknown","n/a","btrfs_qgroups_enabled_unavailable")
    elif fs in("ext2","ext3","ext4"):
        r=("unknown","n/a","ext_quota_option_unverified" if keys&EXT else "ext_quota_superblock_unobservable")
    elif fs=="tmpfs":
        r=("enabled","enforced","tmpfs_quota_option") if keys&TM else ("disabled","n/a","tmpfs_quota_options_absent")
    else: r=("unknown","n/a","unsupported_fstype")
    return (fs,best["mp"])+r,dc,cov,note
def verdict(rows):
    s={r[2] for r in rows}
    return (1,"QUOTA_ENABLED") if "enabled" in s else (2,"QUOTA_STATE_UNKNOWN") if "unknown" in s else (0,"QUOTA_DISABLED")
D="/home/vgpnk/Projects/shokunin/mori-shokunin/.ufo/waves/round-23/frozen/quota-cases"
for p in sorted(glob.glob(D+"/*.json")):
    c=json.load(open(p)); fx=c["fixture"]; ex=c["expected"]; name=os.path.basename(p)[:-5]
    try:
        ms=parse(fx["mountinfo"])
        rows=[];info=[]
        for row in fx["paths"]:
            t,dc,cov,note=classify(fx,row,ms); rows.append(t)
            # physical plausibility: is any covering mount hidden by a shorter later-mounted cover? report par chain
            info.append((row["path"],dc,note,[(m["id"],m["par"],m["mp"]) for m in cov]))
        code,fid=verdict(rows)
        got=[dict(zip(["fstype","mount_point","quota_state","enforcement","basis"],r)) for r in rows]
    except Exception as e:
        code,fid,got,info=2,"QUOTA_SETUP",[],[str(e)]
    exp=[{k:v for k,v in e.items() if k!="path"} for e in ex["paths"]]
    ok=(code==ex["exit"] and fid==ex["finding_id"] and got==exp)
    print(("OK  " if ok else "DIFF"),name,ex["exit"],ex["finding_id"],"| mine",code,fid)
    if not ok:
        print("   exp",exp); print("   got",got)
    for i in info: print("   ",i)
