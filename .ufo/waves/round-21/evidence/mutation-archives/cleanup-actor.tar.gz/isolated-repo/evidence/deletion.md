SYNTHETIC observation disappeared; disposition remains unknown.
