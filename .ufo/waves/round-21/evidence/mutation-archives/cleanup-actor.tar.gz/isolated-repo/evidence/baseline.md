SYNTHETIC required observation; not historical settlement evidence.
